# Windows Security Operations Lab

A mission-based, discovery-oriented lab for learning Windows security through exploration.

## Overview

This is not a step-by-step lab. You are given **missions** with clear objectives but no instructions on how to achieve them. You must explore, research, experiment, and sometimes fail to learn. Hints are available but cost points.

You play the role of a **security analyst** who has just joined a company and been handed a Windows server that "probably needs some attention." Your job is to audit, harden, instrument, and defend it.

## Prerequisites

### Required

- A Windows Server 2025 Datacenter VM (EC2)
  - Minimum: 2 vCPUs, 4 GB RAM, 40 GB disk
  - EC2: `t3.micro` with Windows Server 2025 AMI
- Administrator access to the VM
- RDP client or SSM Session Manager access

### Recommended Knowledge

- Basic Windows navigation (PowerShell, Event Viewer, Services)
- Concepts from the Windows Security slide module
- Familiarity with the AWS CLI (if using EC2)

### Optional (for bonus missions)

- A second Windows VM (for lateral movement missions)
- Sysmon installer: https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon
- Sysinternals Suite: https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite

## Lab Structure

| Phase | Missions | Points Available | Estimated Time |
|-------|----------|-----------------|----------------|
| 0: Setup | Run the setup script | 0 | 15 min |
| 1: Reconnaissance | Discover what's wrong | 100 | 45 min |
| 2: Hardening | Fix the issues | 150 | 60 min |
| 3: Instrumentation | Set up detection | 100 | 45 min |
| 4: Attack & Detect | Run attacks, catch them | 150 | 60 min |
| 5: Incident Response | Investigate a breach | 100 | 45 min |
| **Bonus** | Extra challenges | 100 | Open-ended |
| **Total** | | **700** | ~4.5 hours |

## Scoring

- Each mission has a **point value** based on difficulty
- **Hints** are available for each mission — using a hint reduces the mission's points by 30%
- Missions are pass/fail: you either achieve the objective or you don't
- Record your findings in a **lab journal** (a text file) — this is your evidence of completion
- There is no autograder. Honestly assess your own progress or have a peer verify.

## Getting Started

1. Spin up a Windows Server 2025 VM
2. Copy `setup-lab-environment.ps1` to the VM
3. Run it as Administrator
4. Open `missions.md` and begin Phase 1

## Files

| File | Purpose |
|------|---------|
| `README.md` | This file — overview and logistics |
| `setup-lab-environment.ps1` | PowerShell script that configures the vulnerable environment |
| `missions.md` | The mission guide — your objectives and hints |

## Cleanup

After completing the lab, you can safely delete the VM. If using EC2, terminate the instance to avoid charges.

## Important Note

This lab creates intentional security misconfigurations on the target VM. **Never run the setup script on a production system or a machine you care about.** Use a disposable VM only.
