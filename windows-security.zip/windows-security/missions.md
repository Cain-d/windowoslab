# Windows Security Operations: Mission Briefing

## Your Situation

It's your first week as a security analyst at Kōtuku Technologies. Your manager drops by your desk:

> "The Windows server at `WIN-LAB01` was set up by a contractor last year. Nobody's really looked at it since. It runs some internal tools and a few scheduled jobs. Can you give it a security review? I have a bad feeling about it."

You have full administrator access. Your job: find everything wrong, fix it, set up proper monitoring, and make sure you'd know if someone breaks in.

**Record all findings in a lab journal** (a text file on your desktop). For each finding, note: what you found, why it's a risk, and what you did about it. This is your evidence of completion.

---

## Scoring

| Score | Rating |
|-------|--------|
| 0–199 | Apprentice — you found the obvious stuff |
| 200–399 | Analyst — solid security review |
| 400–549 | Engineer — thorough hardening and detection |
| 550–700 | Architect — you left nothing unturned |

**Hint penalty**: Using a hint reduces that mission's points by 30%. You can use multiple hints per mission (each costs 30% of the original value, stacking).

---

## Phase 0: Setup

Run `setup-lab-environment.ps1` as Administrator on your Windows VM. Wait for the "setup complete" message, then begin.

---

## Phase 1: Reconnaissance (100 points)

*"You can't defend what you don't understand."*

Your goal is to discover what's wrong with this machine. Don't fix anything yet — just find and document.

---

### Mission 1.1: Ghost Accounts (15 points)

**Objective**: Identify all local user accounts that should not exist or are misconfigured. In your journal, list each account, what's wrong with it, and the risk it poses.

**Completion criteria**: Find at least 5 problematic accounts and explain the issue with each.

<details>
<summary>Hint 1 (−30%)</summary>
PowerShell can list all local users and their properties. Look at descriptions, password settings, group memberships, and whether accounts are enabled that shouldn't be.
</details>

<details>
<summary>Hint 2 (−30%)</summary>
Check which accounts are in the Administrators and Remote Desktop Users groups. Are service accounts in groups they don't need to be in? Is the Guest account enabled?
</details>

---

### Mission 1.2: The Password Problem (10 points)

**Objective**: Determine the current password policy for this machine. Document every setting that violates security best practices (compare against CIS benchmarks or common sense).

**Completion criteria**: Identify at least 4 weak password policy settings.

<details>
<summary>Hint (−30%)</summary>
<code>net accounts</code> shows the local password policy. You can also export via <code>secedit</code>. Compare minimum length, complexity, lockout threshold, and password age settings.
</details>

---

### Mission 1.3: Listening in the Dark (15 points)

**Objective**: Find all inbound firewall rules that are overly permissive or suspicious. Document the rule name, port, and why it's a concern.

**Completion criteria**: Find at least 3 suspicious firewall rules. For each, explain what an attacker could do with that open port.

<details>
<summary>Hint (−30%)</summary>
Think about which ports are commonly associated with attack tools, reverse shells, or unnecessary services. 4444 and 1337 have particular reputations.
</details>

---

### Mission 1.4: Things That Run in the Night (20 points)

**Objective**: Find all persistence mechanisms on this machine — anything that runs automatically on boot, login, or on a schedule. Determine which are legitimate and which are suspicious.

**Completion criteria**: Identify at least 3 suspicious auto-start items. For each, explain what it does and why it's concerning.

<details>
<summary>Hint 1 (−30%)</summary>
Check scheduled tasks, services, registry Run keys, and the Startup folder. Not all persistence is in the same place.
</details>

<details>
<summary>Hint 2 (−30%)</summary>
For scheduled tasks, look at the <em>action</em> (what it runs) and the <em>principal</em> (what account it runs as). Encoded PowerShell commands are almost always suspicious. A task that resets a password weekly is a red flag.
</details>

---

### Mission 1.5: Secrets in the Open (20 points)

**Objective**: Find all plaintext credentials, API keys, and sensitive data stored insecurely on the filesystem. Include PowerShell history.

**Completion criteria**: Find at least 4 distinct credentials or secrets. For each, identify the type (database password, AWS key, etc.) and the risk.

<details>
<summary>Hint (−30%)</summary>
Scripts directories and configuration files are common hiding places. PowerShell keeps a command history file. Think about what files a sysadmin might have left behind.
</details>

---

### Mission 1.6: The Blind Spots (20 points)

**Objective**: Determine what this machine is NOT logging. Identify disabled or missing audit policies that would leave you blind to attacks.

**Completion criteria**: Find at least 3 audit categories that are disabled or insufficient. Explain what attacks you'd miss without each one.

<details>
<summary>Hint (−30%)</summary>
<code>auditpol /get /category:*</code> shows the current audit configuration. Compare against what you'd need to detect logon attacks, process execution, and privilege changes.
</details>

---

## Phase 2: Hardening (150 points)

*"Now break out the tools and fix everything you found — and everything you didn't."*

---

### Mission 2.1: Account Lockdown (20 points)

**Objective**: Remediate all the account issues you found in Phase 1. When you're done, only legitimate accounts should exist, with appropriate group memberships and settings.

**Completion criteria**:
- All unnecessary accounts disabled or deleted
- No service accounts in the Administrators group
- Guest account disabled
- Stale/intern accounts removed
- Document each change in your journal

<details>
<summary>Hint (−30%)</summary>
<code>Remove-LocalUser</code>, <code>Disable-LocalUser</code>, <code>Remove-LocalGroupMember</code>. For service accounts, figure out the minimum group membership they actually need.
</details>

---

### Mission 2.2: Password Policy Overhaul (15 points)

**Objective**: Configure the local password policy to meet a reasonable security standard.

**Completion criteria**: Minimum password length 14+, complexity enabled, lockout after 5 failed attempts, and sensible password age settings. Document your chosen values and why.

<details>
<summary>Hint (−30%)</summary>
<code>net accounts</code> can set some values. For the full policy, use <code>secpol.msc</code> or create a secedit template. CIS Benchmark Level 1 for Windows is a good reference.
</details>

---

### Mission 2.3: Firewall Fortress (20 points)

**Objective**: Remove all suspicious firewall rules and ensure the firewall is properly configured on all profiles (Domain, Private, Public).

**Completion criteria**:
- All suspicious inbound rules removed
- Default inbound action set to Block on all profiles
- Firewall enabled on all profiles
- Only necessary management ports allowed (and scoped to specific source addresses if possible)
- Document your final rule set

<details>
<summary>Hint (−30%)</summary>
<code>Get-NetFirewallRule | Where-Object { $_.Direction -eq 'Inbound' -and $_.Action -eq 'Allow' }</code> lists all inbound allow rules. Think about which ports this server actually needs open.
</details>

---

### Mission 2.4: Purge the Persistence (25 points)

**Objective**: Remove every illegitimate persistence mechanism you found — and any you may have missed. Verify nothing suspicious survives a reboot.

**Completion criteria**:
- All suspicious scheduled tasks removed
- All suspicious registry Run key entries removed
- Startup folder cleaned
- Suspicious services removed or disabled
- Reboot the machine and verify nothing suspicious runs

<details>
<summary>Hint (−30%)</summary>
<code>Unregister-ScheduledTask</code>, <code>Remove-ItemProperty</code> for registry keys, and <code>sc.exe delete</code> for services. After cleanup, reboot and check Task Manager / Process Explorer for anything unexpected.
</details>

---

### Mission 2.5: Secrets Remediation (15 points)

**Objective**: Remove all plaintext credentials from the filesystem and PowerShell history. In your journal, describe how these credentials SHOULD be managed in a production environment.

**Completion criteria**:
- All plaintext credential files deleted or redacted
- PowerShell history cleared
- Journal entry explaining the proper alternative for each type of secret (database creds, AWS keys, API keys)

<details>
<summary>Hint (−30%)</summary>
For the "how should they be managed" part, think about AWS Secrets Manager, IAM roles instead of access keys, environment variables injected from a vault, and Windows Credential Manager or DPAPI for local secrets.
</details>

---

### Mission 2.6: Secure the Protocols (20 points)

**Objective**: Find and fix insecure protocol and authentication settings on this machine.

**Completion criteria**: Fix at least 4 of the following (you must discover which ones are misconfigured):
- SMBv1 status
- WDigest credential caching
- Network Level Authentication for RDP
- PowerShell execution policy
- Windows Defender real-time protection
- LSA protection (RunAsPPL)

<details>
<summary>Hint (−30%)</summary>
Each of these is a registry value or feature toggle. Research the registry path for each one. <code>Get-SmbServerConfiguration</code>, <code>Get-MpPreference</code>, and <code>Get-ItemProperty</code> on the relevant registry keys will show current state.
</details>

---

### Mission 2.7: The Service That Shouldn't (15 points)

**Objective**: Find the service with an unquoted service path and fix it. Also find any services running as LocalSystem that don't need to.

**Completion criteria**:
- Identify the unquoted path vulnerability and explain how it could be exploited
- Fix the service path (or remove the service if it's not needed)
- Identify services running as LocalSystem unnecessarily

<details>
<summary>Hint (−30%)</summary>
<code>Get-WmiObject Win32_Service | Where-Object { $_.PathName -notmatch '^"' -and $_.PathName -match '\s' }</code> finds unquoted paths with spaces. Think about what happens when Windows tries to resolve <code>C:\Program Files\Lab Monitoring\Agent Service\monitor.exe</code> without quotes.
</details>

---

### Mission 2.8: Verify Your Work (20 points)

**Objective**: After all hardening, produce a security posture report. Run a systematic check across all categories and confirm nothing was missed.

**Completion criteria**: A summary document listing:
- All accounts and their group memberships
- Current password policy
- Firewall rule summary (inbound allow rules only)
- Scheduled tasks list
- Services running as LocalSystem/NetworkService
- Auto-start entries (registry Run keys, Startup folder)
- Audit policy configuration
- Protocol/feature status (SMBv1, WDigest, NLA, Defender)

<details>
<summary>Hint (−30%)</summary>
Write a PowerShell script that collects all of this into a single report. This is a useful skill — security baselines are often checked with scripts. Each check is one or two commands.
</details>

---

## Phase 3: Instrumentation (100 points)

*"You've locked the doors. Now install the cameras."*

---

### Mission 3.1: Enable Full Audit Visibility (25 points)

**Objective**: Configure the Windows audit policy so that you would detect: failed logons, successful logons, process creation (with command lines), privilege use, account management changes, and security policy changes.

**Completion criteria**:
- Audit policy configured for all relevant subcategories
- Process creation command-line logging enabled
- Verify by triggering a test event and confirming it appears in the Security log

<details>
<summary>Hint (−30%)</summary>
<code>auditpol /set /subcategory:"X" /success:enable /failure:enable</code> for each category. For command-line logging, there's a GPO setting under <em>Process Creation</em>. Alternatively, a registry key enables it.
</details>

---

### Mission 3.2: Deploy Sysmon (30 points)

**Objective**: Install Sysmon with a community-recommended configuration. Verify it is generating events.

**Completion criteria**:
- Sysmon installed and running as a service
- Using a real configuration file (not the bare default)
- Demonstrate that Sysmon is logging process creation (Event ID 1), network connections (Event ID 3), and file creation (Event ID 11) by triggering each and finding the events

<details>
<summary>Hint 1 (−30%)</summary>
Download Sysmon from Sysinternals. For a config file, search for "SwiftOnSecurity sysmon-config" or "olafhartong sysmon-modular" on GitHub.
</details>

<details>
<summary>Hint 2 (−30%)</summary>
<code>sysmon64.exe -accepteula -i config.xml</code> to install. Events appear in <em>Event Viewer > Applications and Services Logs > Microsoft > Windows > Sysmon > Operational</em>.
</details>

---

### Mission 3.3: PowerShell Logging Trifecta (25 points)

**Objective**: Enable all three PowerShell logging mechanisms: Module Logging, Script Block Logging, and Transcription.

**Completion criteria**:
- All three enabled (via GPO, registry, or both)
- Run a test command and verify it appears in the PowerShell event log (Event ID 4104)
- Verify a transcription file is created
- Document where each log is stored

<details>
<summary>Hint (−30%)</summary>
These are registry keys under <code>HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell</code>. Each logging type has its own subkey. For transcription, you also specify an output directory.
</details>

---

### Mission 3.4: Build a Detection Rule (20 points)

**Objective**: Using only Event Viewer (no SIEM), create a custom event log view or filter that would alert you to one of the following:
- Someone accessing LSASS (credential theft)
- A new service being installed
- PowerShell running an encoded command
- A new user being added to the Administrators group

Pick ONE and build the detection.

**Completion criteria**:
- A custom view in Event Viewer with the correct filter
- A screenshot or description of the filter criteria
- A test that demonstrates the detection fires (trigger the event yourself and find it in your custom view)

<details>
<summary>Hint (−30%)</summary>
In Event Viewer, right-click <em>Custom Views</em> > <em>Create Custom View</em>. Filter by event source (Sysmon, Security) and event ID. For encoded PowerShell, Script Block Logging (4104) captures the decoded content — search for <code>FromBase64String</code> or <code>-EncodedCommand</code>.
</details>

---

## Phase 4: Attack & Detect (150 points)

*"Time to think like an attacker. Then catch yourself."*

In this phase, you simulate attack techniques and verify your instrumentation catches them. For each mission, you must both **execute the attack** and **find the evidence** in your logs.

---

### Mission 4.1: The Suspicious Logon (20 points)

**Objective**: Generate a failed logon and a successful logon using different methods. Find both events in the Security log.

**Completion criteria**:
- Trigger a failed logon attempt (wrong password)
- Trigger a successful logon
- Find both events (4625 and 4624) in Event Viewer
- Document the logon type, source, and account for each

<details>
<summary>Hint (−30%)</summary>
<code>runas /user:nonexistent cmd</code> triggers a failed logon. A successful logon via <code>runas</code> with a valid account generates a different event. Look at the <em>Logon Type</em> field — it tells you how the authentication occurred.
</details>

---

### Mission 4.2: Living Off the Land (30 points)

**Objective**: Execute three different "Living Off the Land" (LOLBin) techniques — using legitimate Windows binaries for suspicious purposes. Then find evidence of each in your Sysmon or Security logs.

Pick any three from this list (or research your own):
- Use `certutil.exe` to download a file from the internet
- Use `mshta.exe` to execute code
- Use `rundll32.exe` to execute a DLL function
- Use `bitsadmin` to download a file
- Use `wmic` to start a process

**Completion criteria**:
- Execute three LOLBin techniques (harmless payloads only — download a text file, echo something, etc.)
- Find Sysmon Event ID 1 (Process Creation) for each
- Explain why a defender should flag each one

<details>
<summary>Hint (−30%)</summary>
Example (certutil): <code>certutil -urlcache -split -f http://example.com/robots.txt C:\Temp\test.txt</code>. This is legitimate certutil functionality but commonly abused. The key evidence is in Sysmon Event 1 — look at the CommandLine field.
</details>

---

### Mission 4.3: Persistence Planting (25 points)

**Objective**: Create three different persistence mechanisms of your own choosing (different from the ones the setup script planted). Then find the evidence in your logs.

**Completion criteria**:
- Create three persistence mechanisms (scheduled task, registry key, WMI subscription, service, or other)
- For each: find the creation event in your logs (Sysmon or Security)
- Remove all three after documenting them

<details>
<summary>Hint (−30%)</summary>
Sysmon events: 12/13 for registry, Event ID 4698 (Security) for scheduled tasks, 7045 (System) for services, Sysmon 19/20/21 for WMI subscriptions. Create something benign (run <code>calc.exe</code> or <code>echo hello</code>) and then verify the log trail.
</details>

---

### Mission 4.4: The Encoded Command (25 points)

**Objective**: Create a Base64-encoded PowerShell command, execute it, and then find the decoded content in your Script Block Logging output.

**Completion criteria**:
- Encode a harmless PowerShell command to Base64
- Run it with `powershell -EncodedCommand <base64>`
- Find Event ID 4104 in the PowerShell Operational log
- Confirm the log shows the **decoded** content (not just the Base64 string)

<details>
<summary>Hint (−30%)</summary>
To encode: <code>[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes('Write-Host "Hello from encoded command"'))</code>. Script Block Logging is specifically designed to log code after all deobfuscation layers, which is why it's so valuable for detection.
</details>

---

### Mission 4.5: Credential Exposure Audit (25 points)

**Objective**: Without using any external tools, determine what credential-related information is accessible on this machine. Then document what defences would prevent each exposure.

Investigate:
- Can you read the SAM database?
- What's in the Credential Manager vault?
- What does the PowerShell history reveal?
- Are there any cached domain credentials?
- Is WDigest enabled (did you fix it in Phase 2)?
- Is LSA protection (RunAsPPL) enabled?

**Completion criteria**:
- Document the current state of each credential storage location
- For each, state whether it's adequately protected and what you'd change

<details>
<summary>Hint (−30%)</summary>
<code>reg query "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest"</code> for WDigest. <code>reg query "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v RunAsPPL</code> for LSA protection. <code>cmdkey /list</code> for Credential Manager. The SAM file is locked while Windows is running — what would an attacker do to get around that?
</details>

---

### Mission 4.6: The Alert That Matters (25 points)

**Objective**: Design and document a "Top 5 Alerts" list for this server. For each alert, specify:
1. What event or pattern triggers it
2. The data source (which log, which event ID)
3. What attack it detects
4. Expected false positive rate (low/medium/high)
5. Recommended response action

**Completion criteria**: A written document with 5 alerts that would give meaningful security coverage for this server. Defend your choices.

<details>
<summary>Hint (−30%)</summary>
Think about the highest-impact attacks: credential theft (LSASS access), persistence (new service/task), lateral movement (unusual logon source), privilege escalation (admin group change), and defence evasion (log clearing). What events would each generate?
</details>

---

## Phase 5: Incident Response (100 points)

*"The SOC just called. Something triggered at 2 AM last night."*

You discover a file at `C:\Windows\Temp\incident-notes.txt` from a previous analyst. Read it. Your job is to investigate.

---

### Mission 5.1: Read the Room (15 points)

**Objective**: Read the incident notes file. Based on its contents, determine:
1. What type of incident is this?
2. What is the suspected attacker infrastructure (IP/hostname)?
3. What initial indicators of compromise (IOCs) are mentioned?
4. What is the initial scope of the incident?

**Completion criteria**: A written incident summary in your journal with answers to all four questions.

---

### Mission 5.2: IOC Hunt (25 points)

**Objective**: Using the IOCs from the incident notes, search the machine for all related artefacts. Trace every reference to the attacker's infrastructure across all locations: registry, scheduled tasks, files, firewall rules, network connections, and logs.

**Completion criteria**: A complete list of every artefact on the machine related to the IOCs. You should find references in at least 3 different locations.

<details>
<summary>Hint (−30%)</summary>
Search the registry for the IP address: <code>reg query HKLM /s /f "10.10.10" 2>$null</code>. Search the filesystem: <code>Select-String -Path C:\*.* -Pattern "10.10.10" -Recurse</code>. Check scheduled tasks' actions. Check firewall rules.
</details>

---

### Mission 5.3: Timeline Reconstruction (25 points)

**Objective**: Build a timeline of the incident. Using the evidence you've found (persistence mechanisms, credential files, scheduled tasks, account changes, PowerShell history), reconstruct the likely sequence of events.

**Completion criteria**: A written timeline with at least 5 events in chronological order, explaining what the attacker likely did and in what sequence. Include timestamps where available and logical ordering where not.

<details>
<summary>Hint (−30%)</summary>
Use file timestamps (<code>Get-ChildItem | Select Name, CreationTime, LastWriteTime</code>), scheduled task creation dates, account creation dates, and PowerShell history ordering to build the timeline. Think about what an attacker would do first (credentials), then (persistence), then (data exfiltration).
</details>

---

### Mission 5.4: Containment and Eradication (20 points)

**Objective**: Based on your investigation, perform full containment and eradication. Remove every trace of the attacker's presence.

**Completion criteria**:
- All attacker artefacts removed (persistence, files, accounts, rules)
- A containment checklist documenting each action taken
- Verification that nothing related to the attacker survives a reboot

---

### Mission 5.5: Lessons Learned (15 points)

**Objective**: Write a brief (half-page) lessons-learned report answering:
1. What was the root cause that allowed this incident?
2. What three controls would have prevented it?
3. What three controls would have detected it sooner?
4. What would you change about this machine's security posture going forward?

**Completion criteria**: A thoughtful written report that connects the incident to the hardening and instrumentation work you did in earlier phases.

---

## Bonus Missions (100 points)

*"For those who want to go further."*

---

### Bonus 1: Write a Hardening Script (30 points)

**Objective**: Write a PowerShell script that automates the hardening steps you performed in Phase 2. The script should be idempotent (safe to run multiple times) and produce a summary of changes made.

**Completion criteria**: A working `.ps1` script that, when run on a fresh Windows VM, applies your security baseline. Include comments explaining each section.

---

### Bonus 2: Sysmon Config Customisation (20 points)

**Objective**: Starting from a community Sysmon config, add three custom detection rules for attack techniques not covered by the default config. Document what each rule detects and why you added it.

**Completion criteria**: A modified Sysmon XML config with your additions clearly commented, plus a test for each rule.

---

### Bonus 3: The Lateral Movement Challenge (30 points)

*Requires a second Windows VM.*

**Objective**: Set up two VMs on the same network. From VM1, attempt to access VM2 using at least two different remote execution methods (PsExec, WinRM, WMI, RDP, scheduled task). Document the evidence left on both machines for each method.

**Completion criteria**: A comparison table showing each lateral movement method, the logon type it generates, whether credentials are cached on the target, and the Event IDs generated on both source and destination.

---

### Bonus 4: GPO Security Baseline (20 points)

**Objective**: Research the CIS Benchmark for Windows Server 2022 (Level 1). Create a document listing the 10 most impactful settings and whether your lab machine currently complies with each.

**Completion criteria**: A 10-row compliance table with setting name, recommended value, current value, and compliance status (pass/fail).

---

## Final Debrief

When you're done, review your lab journal. You should have:

- A full reconnaissance report of everything wrong with the machine
- Evidence of every hardening action taken
- A working Sysmon deployment and full audit policy
- Proof that you can execute AND detect common attack techniques
- An incident investigation with timeline and lessons learned

This is the workflow of a real security analyst. The tools and techniques you practiced here are used daily in SOCs, during pentests, and in incident response engagements worldwide.

**Congratulations on completing the Windows Security Operations Lab.**
